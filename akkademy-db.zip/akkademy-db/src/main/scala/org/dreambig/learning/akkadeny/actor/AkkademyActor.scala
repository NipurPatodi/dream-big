package org.dreambig.learning.akkadeny.actor

import akka.actor.Actor
import akka.event.Logging

import org.dreambig.learning.akkadeny.messages.SimplePutMessage

import scala.collection.mutable

class AkkademyActor extends Actor{

  val map = new mutable.HashMap[String,Object]
  val log = Logging(context.system, this)


  override def receive: Receive = {
    case SimplePutMessage(key,value)=>
      log.info("Message receive key={} value={}",key,value)
      map.put(key,value)

    case o=> log.info("Unknown Message {}",o)
  }

}
