package org.dreambig.learning.akkadeny.messages

case class SimplePutMessage(key:String, value:Object)


