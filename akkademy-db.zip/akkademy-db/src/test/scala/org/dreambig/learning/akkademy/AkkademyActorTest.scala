package org.dreambig.learning.akkademy

import akka.actor.ActorSystem
import akka.testkit.TestActorRef
import org.dreambig.learning.akkadeny.actor.AkkademyActor
import org.dreambig.learning.akkadeny.messages.SimplePutMessage
import org.scalatest._

class AkkademyActorTest extends FlatSpec with Matchers {

  implicit val system = ActorSystem()


  "Hello" should "have tests" in {
    val actorRef = TestActorRef(new AkkademyActor)
    actorRef ! SimplePutMessage("key", "guddu")
    val akkademyDb = actorRef.underlyingActor
    akkademyDb.map.get("key") should equal(Some("guddu"))
  }
}
